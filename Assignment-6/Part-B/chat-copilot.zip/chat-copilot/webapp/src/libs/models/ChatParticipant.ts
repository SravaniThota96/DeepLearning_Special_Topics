// Copyright (c) Microsoft. All rights reserved.

export interface IChatParticipant {
    userId: string;
    chatId: string;
}
